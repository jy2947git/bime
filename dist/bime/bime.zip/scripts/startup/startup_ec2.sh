#!/bin/bash
#
# this script is hooked in the AMI to run at EC2 instance start up.
# it should be installed on all instances.
#
# The Ubuntu and Debian EC2 images published on http://alestic.com allow you to send in a startup script using the EC2 user-data parameter when you run a new instance. This functionality is useful for automating the installation and configuration of software on EC2 instances.
#
# The basic rule followed by the image is:
#
#    If the instance user-data starts with the two characters #! then the instance runs it as the root user on the first boot.
#
#The �user-data script� is run late in the startup process, so you can assume that networking and other system services are functional.
echo 'get user data from instance...'
echo 'internal IP:'
echo 'Queue IP:'
echo 'role:'
#
# if role is 'haproxy', then run start_haproxy_listener.sh
#
sudo /usr/local/bime-home/startup/start_haproxy_listener.sh localhost 5672 guest guest
#
# if role is 'bime', run the start_bime_client_listener.sh
#
sudo /usr/local/bime-home/startup/start_bime_client_listener.sh localhost 5672 guest guest