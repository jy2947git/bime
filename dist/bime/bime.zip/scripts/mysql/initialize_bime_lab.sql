
INSERT INTO `lab` (name, storageIdentity) VALUES('bime', '/bime');

