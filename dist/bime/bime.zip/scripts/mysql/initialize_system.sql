
INSERT INTO `role` (description,id,version) VALUES ('High Level Users','ROLE_SUPER_USER',0);
INSERT INTO `role` (description,id,version) VALUES ('Administrator role (can edit Users)','ROLE_ADMIN',0);
INSERT INTO `role` (description,id,version) VALUES ('Default role for all Users','ROLE_USER',0);


