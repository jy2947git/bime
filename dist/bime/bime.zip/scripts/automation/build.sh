#!/bin/bash

if [ -d source ]; then
echo 'find source directory'
else
echo 'creating source directory'
mkdir source
fi
cd source
echo 'download file from svn....'
svn --username jy2947 --password jy2947 --non-interactive checkout --force http://svn.bimelab.com/svn/svn-repository/bime
echo 'running build script'
/usr/local/apache-ant-1.7.1/bin/ant -f bime/build.xml
cp /usr/local/bime-home/bime/source/bime/dist/bime/bime.zip /usr/local/bime-home/bime
exit 0

